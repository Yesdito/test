package com.dynamsoft.documentscanner;

public class DeviceConfiguration {
    public boolean IfShowUI = false;
    public int Resolution = 200;
    public boolean IfFeederEnabled = false;
    public boolean IfDuplexEnabled = false;

}
