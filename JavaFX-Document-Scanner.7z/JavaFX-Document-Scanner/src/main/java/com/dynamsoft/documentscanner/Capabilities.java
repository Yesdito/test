package com.dynamsoft.documentscanner;

import java.util.ArrayList;
import java.util.List;

public class Capabilities {
    public String exception = "";
    public List<CapabilitySetup> capabilities = new ArrayList<CapabilitySetup>();
}
