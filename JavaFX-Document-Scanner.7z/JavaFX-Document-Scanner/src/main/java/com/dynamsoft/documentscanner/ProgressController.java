package com.dynamsoft.documentscanner;

public class ProgressController {
}
