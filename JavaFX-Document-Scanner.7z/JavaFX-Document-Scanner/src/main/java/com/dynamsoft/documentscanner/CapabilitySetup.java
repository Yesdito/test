package com.dynamsoft.documentscanner;

public class CapabilitySetup {
    public int capability;
    public Object curValue;
    public String exception = "ignore";
}
