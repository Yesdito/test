package com.dynamsoft.documentscanner;

public class Scanner {
    public String name;
    public int type;
    public String device;
    public Scanner(String name, int type, String device){
        this.name = name;
        this.type = type;
        this.device = device;
    }
}
